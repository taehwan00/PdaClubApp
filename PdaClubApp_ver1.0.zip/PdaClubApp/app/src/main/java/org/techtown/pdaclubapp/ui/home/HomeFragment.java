package org.techtown.pdaclubapp.ui.home;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import org.techtown.pdaclubapp.Community;
import org.techtown.pdaclubapp.Introduce;
import org.techtown.pdaclubapp.Notice;
import org.techtown.pdaclubapp.R;
import org.techtown.pdaclubapp.StartActivity;
import org.techtown.pdaclubapp.Study;

public class HomeFragment extends Fragment {

    private HomeViewModel homeViewModel;
    private ImageView introduceimg, noticeimg, studyimg, communityimg;


    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        homeViewModel =
                ViewModelProviders.of(this).get(HomeViewModel.class);
        View root = inflater.inflate(R.layout.fragment_home, container, false);

        introduceimg = root.findViewById(R.id.introduceimg);
        noticeimg = root.findViewById(R.id.noticeimg);
        studyimg = root.findViewById(R.id.studyimg);
        communityimg = root.findViewById(R.id.communityimg);


        introduceimg.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                Intent intent = new Intent(
                        getActivity().getApplicationContext(), // 현재 화면의 제어권자
                        Introduce.class); // 다음 넘어갈 클래스 지정
                startActivity(intent); // 다음 화면으로 넘어간다
                return true;
            }
        });

        noticeimg.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                Intent intent = new Intent(
                        getActivity().getApplicationContext(), // 현재 화면의 제어권자
                        Notice.class); // 다음 넘어갈 클래스 지정
                startActivity(intent); // 다음 화면으로 넘어간다
                return true;
            }
        });

        studyimg.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                Intent intent = new Intent(
                        getActivity().getApplicationContext(), // 현재 화면의 제어권자
                        Study.class); // 다음 넘어갈 클래스 지정
                startActivity(intent); // 다음 화면으로 넘어간다
                return true;
            }
        });

        communityimg.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                Intent intent = new Intent(
                        getActivity().getApplicationContext(), // 현재 화면의 제어권자
                        StartActivity.class); // 다음 넘어갈 클래스 지정
                startActivity(intent); // 다음 화면으로 넘어간다
                return true;
            }
        });




        return root;
    }
}
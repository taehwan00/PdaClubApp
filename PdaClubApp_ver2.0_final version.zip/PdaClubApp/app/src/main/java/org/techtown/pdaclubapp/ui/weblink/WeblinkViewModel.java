package org.techtown.pdaclubapp.ui.weblink;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class WeblinkViewModel extends ViewModel {  private MutableLiveData<String> mText;

    public WeblinkViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("PDA 홈페이지로 이동");
    }

    public LiveData<String> getText() {
        return mText;
    }
}